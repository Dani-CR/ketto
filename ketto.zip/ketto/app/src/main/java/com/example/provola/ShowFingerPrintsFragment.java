package com.example.provola;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.provola.databinding.FragmentShowdevicesBinding;
import com.example.provola.databinding.FragmentShowfingerprintsBinding;

public class ShowFingerPrintsFragment extends Fragment {

    private FragmentShowfingerprintsBinding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentShowfingerprintsBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.addFP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(ShowFingerPrintsFragment.this)
                        .navigate(R.id.action_showFingerPrintsFragment_to_addFingerPrintFragment);
            }
        });

        binding.backMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(ShowFingerPrintsFragment.this)
                        .navigate(R.id.action_ShowFingerPrintsFragment_to_MenuFragment);
            }
        });

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}