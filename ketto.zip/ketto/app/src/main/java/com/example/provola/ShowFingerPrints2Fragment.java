package com.example.provola;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.provola.databinding.FragmentShowdevicesBinding;
import com.example.provola.databinding.FragmentShowfingerprints2Binding;
import com.example.provola.databinding.FragmentShowfingerprintsBinding;

public class ShowFingerPrints2Fragment extends Fragment {

    private FragmentShowfingerprints2Binding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentShowfingerprints2Binding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.addFP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(ShowFingerPrints2Fragment.this)
                        .navigate(R.id.action_showFingerPrints2Fragment_to_addFingerPrintFragment);
            }
        });

        binding.backMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(ShowFingerPrints2Fragment.this)
                        .navigate(R.id.action_showFingerPrints2Fragment_to_menuFragment2);
            }
        });

        binding.btDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(ShowFingerPrints2Fragment.this)
                        .navigate(R.id.action_showFingerPrints2Fragment_to_showFingerPrintsFragment);
            }
        });

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}