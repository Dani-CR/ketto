package com.example.provola;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.provola.databinding.FragmentAddfingerprintBinding;
import com.example.provola.databinding.FragmentFirstBinding;

public class AddFingerPrintFragment extends Fragment {

    private FragmentAddfingerprintBinding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentAddfingerprintBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.btCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(AddFingerPrintFragment.this)
                        .navigate(R.id.action_addFingerPrintFragment_to_menuFragment2);
            }
        });
        binding.addFP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(AddFingerPrintFragment.this)
                        .navigate(R.id.action_addFingerPrintFragment_to_showFingerPrints2Fragment2);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}